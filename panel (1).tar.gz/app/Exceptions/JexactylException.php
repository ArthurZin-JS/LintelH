<?php

namespace Pterodactyl\Exceptions;

class JexactylException extends \Exception
{
}
